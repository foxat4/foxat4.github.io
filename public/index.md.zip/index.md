---
title: 友链
layout: "links"
slug: "friends"

menu:
    main:
        weight: -70
        Url: /friends/
        params: 
            icon: user
---